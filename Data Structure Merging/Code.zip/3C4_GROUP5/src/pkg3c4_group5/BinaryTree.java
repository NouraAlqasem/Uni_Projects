package pkg3c4_group5;

import pkg3c4_group5.TreeNode;

public class BinaryTree<E> {

    public TreeNode<E> Root;
    public int size;

    public BinaryTree() {
        Root = null;
        size = 0;
    }

    public boolean hasLeft(TreeNode<E> node) {
        return (node.left != null);
    }

    public boolean hasRight(TreeNode<E> node) {
        return (node.right != null);

    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public TreeNode<E> addRoot(E e) {
        if (!isEmpty()) {
            System.out.println("Tree is not empty");
        } else {
            Root = new TreeNode<E>(e);
            size = 1;
        }
        return Root;
    }

    public TreeNode<E> search(TreeNode<E> root, E e, TreeNode<E> result) {
        if (root == null) {
            return null;
        }
        if (e == root.element) {
            return root;
        } else {
            if (root.left != null) {
                result = search(root.left, e, result);
            }

            if (root.right != null) {
                result = search(root.right, e, result);
            }

            return result;
        }

    }

    public void addLeft(E e, E p) {
        TreeNode<E> n = search(Root, p, null);
        if (n != null) {
            if (n.left != null) {
                System.out.println("parent already has a left child");
            } else {
                TreeNode<E> child = new TreeNode(e);
                n.left = child;
                child.parent = n;
                size++;
            }
        } else {
            System.out.println("parent does not exist");
        }
    }

    public void addRight(E e, E p) {
        TreeNode<E> n = search(Root, p, null);
        if (n != null) {
            if (n.right != null) {
                System.out.println("parent already has a left child");
            } else {
                TreeNode<E> child = new TreeNode(e);
                n.right = child;
                child.parent = n;
                size++;
            }
        } else {
            System.out.println("parent does not exist");
        }
    }

    public void printall(TreeNode<E> Tree) {

        if (Tree != null) {
            printall(Tree.left);
            System.out.print(Tree + "\t");
            printall(Tree.right);
        }
    }

    public void MergeTwoTree(E p, BinaryTree tree) {
        TreeNode n = search(Root, p, null);
        if (n != null) {
            if (n.left != null) {
                System.out.println("parent already has a left child ");
            } else {
                TreeNode child = tree.Root;
                n.left = child;
                child.parent = n;
                size += tree.size;
            }
        } else {
            System.out.println("parent does not exist");
        }
    }

    public void InOrder(TreeNode<E> Tree) {
        if (Tree != null) {
            InOrder(Tree.left);
            System.out.print(Tree.element + "\t");
            InOrder(Tree.right);
        }
    }

    public void InOrder() {
        InOrder(Root);
    }

}
