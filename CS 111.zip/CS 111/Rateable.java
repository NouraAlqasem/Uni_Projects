
public interface Rateable {

    public void rate(int score);
}
